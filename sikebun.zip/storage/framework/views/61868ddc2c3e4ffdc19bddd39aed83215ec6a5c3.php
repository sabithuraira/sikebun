

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Daftar Perusahaan</h4>
                <a href="<?php echo e(url('perusahaan/create')); ?>" class="btn btn-secondary btn-round">Tambah Perusahaan</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class=" text-primary">
                        <th>No</th>
                        <th>Nama Perusahaan</th>
                        <th>Komoditas</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($value->nama_perusahaan); ?></td>
                                <td>
                                    <?php if($value->is_karet==1): ?>
                                        &nbsp; KARET &nbsp; 
                                    <?php endif; ?>
                                    
                                    <?php if($value->is_sawit==1): ?>
                                        &nbsp; KELAPA SAWIT &nbsp; 
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('perusahaan/'.$value->id.'/edit')); ?>" class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">edit</i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <?php echo e($datas->links()); ?> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/perusahaan/index.blade.php ENDPATH**/ ?>