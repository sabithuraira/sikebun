<div id="load" class="table-responsive">
    <table class="table m-b-0">
        <?php if(count($datas)==0): ?>
            <thead>
                <tr><th>Tidak ditemukan data</th></tr>
            </thead>
        <?php else: ?>
            <thead>
                <tr class="text-center">
                    <th>Nama</th>
                    <th>Badge No</th>
                    <th>Role</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['name']); ?></td>
                    <td><?php echo e($data['email']); ?></td>
                    <td>
                        <ul>
                        <?php $__currentLoopData = $data->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($role); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td>
                        <a href="<?php echo e(url('user_role/'.$data->id.'/edit')); ?>" class="btn btn-primary btn-link btn-sm">
                            <i class="material-icons">edit</i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php endif; ?>
    </table>
    
    <?php echo e($datas->links()); ?> 
</div><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/user_role/list.blade.php ENDPATH**/ ?>