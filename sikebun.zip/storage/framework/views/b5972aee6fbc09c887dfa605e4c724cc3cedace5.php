

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-danger">
                <h4 class="card-title ">Survey Triwulanan Karet Anda</h4>
                <?php if(auth()->check() && auth()->user()->hasAnyRole('operator')): ?>
                    <a href="<?php echo e(url('survei/karet')); ?>" class="btn btn-secondary btn-round">Tambah Data</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class=" text-primary">
                        <th>No</th>
                        <th>Periode</th>
                        <th>Status</th>
                        <th colspan="2" class="text-center">Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td>Triwulan: <?php echo e($value->triwulan); ?> Tahun: <?php echo e($value->tahun); ?></td>
                                <td><?php echo e($value->listStatus[$value->status_dokumen]); ?></td>
                                <td class="text-center">
                                    <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|approval')): ?>
                                    <a href="<?php echo e(url('survei/'.$value->id.'/karet')); ?>" class="btn btn-primary btn-link btn-sm">
                                        <i class="material-icons">search</i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <?php echo e($datas->links()); ?> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/survei/index_karet.blade.php ENDPATH**/ ?>