

<?php $__env->startSection('content'); ?>
    <div class="container" id="app">
      <br />
      <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
        </div><br />
      <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">Daftar Role</h4>
                        <a href="#" id="btn-tambah" class="btn btn-secondary btn-round">Tambah</a>
                    </div>
                    
                    <div class="card-body">
                        <form action="<?php echo e(url('user_role')); ?>" method="get">
                            <div class="input-group mb-3">
                                <?php echo csrf_field(); ?>
                                <input type="text" class="form-control" name="search" id="search" value="<?php echo e($keyword); ?>" placeholder="Search..">

                                <div class="input-group-append">
                                    <button class="btn btn-info" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>

                        <section class="datas">
                            <?php echo $__env->make('user_role.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                        </section>
                    </div>
                </div>
            </div>
        </div>



    <div class="modal hide" id="wait_progres" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="text-center"><img src="<?php echo asset('lucid/assets/images/loading.gif'); ?>" width="200" height="200" alt="Loading..."></div>
                    <h4 class="text-center">Please wait...</h4>
                </div>
            </div>
        </div>
    </div>


    <div id="form_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span id="myModalLabel">Role</span>
                </div>
                
                <div class="modal-body">
                    <table class="table table-hover table-condensed">
                        <tbody>
                            <tr>
                                <td><input type="text" class="form-control" placeholder="Nama role..." name="role_name" v-model="role_name"></td>  
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
                    <button class="btn btn-primary" data-dismiss="modal" id="btn-submit">Save changes</button>
                </div>
            </div>
        </div>
    </div>


  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="csrf-token" content="<?php echo csrf_field(); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
<script>
    var vm = new Vue({  
        el: "#app",
        data:  {
            role_name : '',
            id: 0,
        },
        methods: {
            saveDatas: function () {
                var self = this;
                $('#wait_progres').modal('show');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                })
                $.ajax({
                    url : "<?php echo e(url('/role/')); ?>",
                    method : 'post',
                    dataType: 'json',
                    data:{
                        id: self.id,
                        role_name: self.role_name,
                    },
                }).done(function (data) {
                    self.id = 0;
                    self.role_name = '';
                    $('#wait_progres').modal('hide');
                    window.location.reload(false);
                }).fail(function (msg) {
                    console.log(JSON.stringify(msg));
                    $('#wait_progres').modal('hide');
                });
            },
        }
    });
    $(document).ready(function() {
    });
    $('#btn-tambah').click(function(e) {
        e.preventDefault();
        $('#form_modal').modal('show');
        vm.id = 0;
    });
    
    $('#btn-edit').click(function(e) {
        e.preventDefault();
        $('#form_modal').modal('show');
        vm.id = $(this).data("id");
        vm.role_name = $(this).data("name");
    });
    $('#btn-submit').click(function() {
        vm.saveDatas();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/user_role/index.blade.php ENDPATH**/ ?>