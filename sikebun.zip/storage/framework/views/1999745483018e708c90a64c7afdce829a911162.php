

<?php $__env->startSection('content'); ?>
    <div class="container" id="app">
      <br />
      <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
        </div><br />
      <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">Daftar Role</h4>
                        <a href="#" id="btn-tambah" class="btn btn-secondary btn-round">Tambah</a>
                    </div>
      <div class="card-body">
          <br/><br/>
          <section class="datas">
            <div id="load" class="table-responsive">
              <table class="table m-b-0">
                  <?php if(count($datas)==0): ?>
                      <thead>
                          <tr><th>Tidak ditemukan data</th></tr>
                      </thead>
                  <?php else: ?>
                      <thead>
                          <tr>
                              <th>Role</th>
                              <th></th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($data['name']); ?></td>
                              <td class="text-center"><a href="#" data-id="<?php echo e($data['id']); ?>" data-name="<?php echo e($data['name']); ?>" id="btn-edit"><i class="icon-pencil text-info"></i></a></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  <?php endif; ?>
              </table>
            </div>
          </section>
    </div>


    <div class="modal hide" id="wait_progres" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="text-center"><img src="<?php echo asset('lucid/assets/images/loading.gif'); ?>" width="200" height="200" alt="Loading..."></div>
                    <h4 class="text-center">Please wait...</h4>
                </div>
            </div>
        </div>
    </div>


    <div id="form_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span id="myModalLabel">Role</span>
                </div>
                
                <div class="modal-body">
                    <table class="table table-hover table-condensed">
                        <tbody>
                            <tr>
                                <td><input type="text" class="form-control" placeholder="Nama role..." name="role_name" v-model="role_name"></td>  
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
                    <button class="btn btn-primary" data-dismiss="modal" id="btn-submit">Save changes</button>
                </div>
            </div>
        </div>
    </div>


  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="csrf-token" content="<?php echo csrf_field(); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
<script>
    var vm = new Vue({  
        el: "#app",
        data:  {
            role_name : '',
            id: 0,
        },
        methods: {
            saveDatas: function () {
                var self = this;
                $('#wait_progres').modal('show');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                })
                $.ajax({
                    url : "<?php echo e(url('/role/')); ?>",
                    method : 'post',
                    dataType: 'json',
                    data:{
                        id: self.id,
                        role_name: self.role_name,
                    },
                }).done(function (data) {
                    self.id = 0;
                    self.role_name = '';
                    $('#wait_progres').modal('hide');
                    window.location.reload(false);
                }).fail(function (msg) {
                    console.log(JSON.stringify(msg));
                    $('#wait_progres').modal('hide');
                });
            },
        }
    });
    $(document).ready(function() {
    });
    $('#btn-tambah').click(function(e) {
        e.preventDefault();
        $('#form_modal').modal('show');
        vm.id = 0;
    });
    
    $('#btn-edit').click(function(e) {
        e.preventDefault();
        $('#form_modal').modal('show');
        vm.id = $(this).data("id");
        vm.role_name = $(this).data("name");
    });
    $('#btn-submit').click(function() {
        vm.saveDatas();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/role/index.blade.php ENDPATH**/ ?>