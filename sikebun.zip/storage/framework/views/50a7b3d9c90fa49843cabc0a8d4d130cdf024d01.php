<?php $__env->startSection('content'); ?>
    <div class="col-md-6 card">
        <div class="card-header card-header-primary">
            <h4 class="card-title">Login</h4>
            <p class="card-category">Masukkan akun anda atau </p>
        </div>
        <div class="card-body">
            
            <?php if(session('status')): ?>
                <div class="text-sm text-green">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            Jika belum memiliki akun, lakukan
            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('register')); ?>">
                Pendaftaran
            </a>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="bmd-label-floating">Email</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="bmd-label-floating">Password</label>
                            <input class="form-control" type="password" name="password" required autocomplete="current-password">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="bmd-label-floating">Remember Password &nbsp;&nbsp;</label>
                            <input type="checkbox" name="remember">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <?php if(Route::has('password.request')): ?>
                            <a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot your password?')); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary pull-right">Login</button>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/auth/login.blade.php ENDPATH**/ ?>