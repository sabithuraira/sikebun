

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <form method="post" action="<?php echo e(url('perusahaan')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('perusahaan._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/perusahaan/create.blade.php ENDPATH**/ ?>