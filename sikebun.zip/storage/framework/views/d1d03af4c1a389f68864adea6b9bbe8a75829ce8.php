

<?php $__env->startSection('content'); ?>
<div class="row clearfix" id="app">
  <div class="col-md-12">
      <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">User Detail Role & Permission</h4>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(url('user_role/'.$id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input name="_method" type="hidden" value="PATCH">
                
                <fieldset disabled>
                    <div class="form-group">
                        <label>Nama :</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $model->name)); ?>">
                    </div>

                    <div class="form-group">
                        <label>Badge No :</label>
                        <input type="text" class="form-control" name="email" value="<?php echo e(old('email', $model->email)); ?>">
                    </div>
                </fieldset>

                <div class="form-group">
                    <label>Roles:</label>

                    <select id="optrole" name="optrole[]" class="ms" multiple="multiple">
                        <?php $__currentLoopData = $all_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <br>
                <button type="submit" class="btn btn-primary">Simpan</button>

              </form>
          </div>
      </div>
  </div>

    <div class="modal hide" id="wait_progres" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="text-center"><img src="<?php echo asset('lucid/assets/images/loading.gif'); ?>" width="200" height="200" alt="Loading..."></div>
                    <h4 class="text-center">Please wait...</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="csrf-token" content="<?php echo csrf_field(); ?>">
    <link rel="stylesheet" href="<?php echo asset('material/assets/js/multi-select/css/multi-select.css'); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo asset('material/assets/js/multi-select/js/jquery.multi-select.js'); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
<script>
    var vm = new Vue({  
        el: "#app",
        data:  {
            list_roles: <?php echo json_encode($model->roles); ?>,
            list_permissions: <?php echo json_encode($model->permissions); ?>,
        },
        methods: {
            getDatas: function(){
                var self = this;
                $('#wait_progres').modal('show');
                var roles_val =[];
                var permissions_val =[];
                for(i=0;i<self.list_roles.length;++i){
                    roles_val.push(self.list_roles[i].id);
                }
                for(i=0;i<self.list_permissions.length;++i){
                    permissions_val.push(self.list_permissions[i].id);
                }
                $("#optrole").val(roles_val);
                $("#optrole").multiSelect("refresh");
                
                $("#optpermission").val(permissions_val);
                $("#optpermission").multiSelect("refresh");
                $('#wait_progres').modal('hide');
            },
        }
    });
    $(document).ready(function() {
        vm.getDatas();
    });
    //I use multiselect plugin here
    // // //Multi-select
    $('#optrole').multiSelect();
    $('#optpermission').multiSelect();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sikebun\resources\views/user_role/edit.blade.php ENDPATH**/ ?>