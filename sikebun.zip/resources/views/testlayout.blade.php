@extends('layouts.admin')

@section('content')
    <div class="col-sm-12">
        Halo semuanya
    </div>
@endsection
